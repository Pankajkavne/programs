package com.mycompany.domain;

public class Product {

    //since this class holds the same data as the db table, it should have the same fields as the table
    String ProductID;
    String ProductName;
    int ProductPrice;

    //default constructor
    public Product(){

    }

    public Product(String productid, String productName, int productPrice) {
        this.ProductID = productid;
        this.ProductName = productName;
        this.ProductPrice = productPrice;
    }

    //getter and setters


    public String getProductid() {
        return ProductID;
    }

    public void setProductid(String productid) {
        this.ProductID = productid;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        this.ProductName = productName;
    }

    public int getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(int productPrice) {
        this.ProductPrice = productPrice;
    }

    @Override
    public String toString(){
        return "Product [ProductID=" + ProductID + ", productName=" + ProductName + ", productPrice=" + ProductPrice + "]";
    }

}